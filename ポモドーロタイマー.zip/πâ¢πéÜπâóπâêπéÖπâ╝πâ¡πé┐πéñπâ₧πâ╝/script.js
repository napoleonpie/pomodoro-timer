class PomodoroTimer {
    constructor() {
        this.workTime = 25 * 60; // 作業時間（秒）
        this.breakTime = 5 * 60; // 休憩時間（秒）
        this.currentMode = 'work'; // 現在のモード（work/break）
        this.timer = null;
        this.isRunning = false;
        
        this.initializeElements();
        this.initializeEventListeners();
    }

    initializeElements() {
        this.timerDisplay = document.getElementById('timer-display');
        this.startBtn = document.getElementById('start-btn');
        this.resetBtn = document.getElementById('reset-btn');
        this.workTimeInput = document.getElementById('work-time');
        this.breakTimeInput = document.getElementById('break-time');
    }

    initializeEventListeners() {
        this.startBtn.addEventListener('click', () => this.handleStart());
        this.resetBtn.addEventListener('click', () => this.handleReset());
        this.workTimeInput.addEventListener('change', () => this.updateWorkTime());
        this.breakTimeInput.addEventListener('change', () => this.updateBreakTime());
    }

    handleStart() {
        if (this.isRunning) return;
        this.isRunning = true;
        this.startBtn.disabled = true;
        this.resetBtn.disabled = false;
        
        this.timer = setInterval(() => {
            if (this.currentMode === 'work') {
                if (this.workTime > 0) {
                    this.workTime--;
                    this.updateDisplay();
                } else {
                    // 作業時間終了、休憩モードに切り替え
                    this.workTime = this.workTimeInput.value * 60;
                    this.currentMode = 'break';
                    this.breakTime = this.breakTimeInput.value * 60;
                    this.updateDisplay();
                }
            } else {
                if (this.breakTime > 0) {
                    this.breakTime--;
                    this.updateDisplay();
                } else {
                    // 休憩時間終了、作業モードに切り替え
                    this.breakTime = this.breakTimeInput.value * 60;
                    this.currentMode = 'work';
                    this.workTime = this.workTimeInput.value * 60;
                    this.updateDisplay();
                }
            }
        }, 1000);
    }

    handleReset() {
        if (!this.isRunning) return;
        
        clearInterval(this.timer);
        this.isRunning = false;
        this.startBtn.disabled = false;
        this.resetBtn.disabled = true;
        
        // デフォルト値に戻す
        this.workTime = this.workTimeInput.value * 60;
        this.breakTime = this.breakTimeInput.value * 60;
        this.currentMode = 'work';
        this.updateDisplay();
    }

    updateWorkTime() {
        this.workTime = this.workTimeInput.value * 60;
        if (!this.isRunning) {
            this.updateDisplay();
        }
    }

    updateBreakTime() {
        this.breakTime = this.breakTimeInput.value * 60;
        if (!this.isRunning) {
            this.updateDisplay();
        }
    }

    updateDisplay() {
        const time = this.currentMode === 'work' ? this.workTime : this.breakTime;
        const minutes = Math.floor(time / 60);
        const seconds = time % 60;
        
        this.timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
}

// インスタンスの生成
const pomodoroTimer = new PomodoroTimer();
